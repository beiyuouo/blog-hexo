/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.Arrays;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Administrator
 */
public class NewServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // processRequest(request, response);
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // processRequest(request, response);
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String name = request.getParameter("name");
            String id = request.getParameter("id");
            String gender = request.getParameter("gender");
            String phone = request.getParameter("phone");
            String mail = request.getParameter("mail");
            String address = request.getParameter("address");
            String food[] = request.getParameterValues("food");
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>NewServlet !!!</title>");
            out.println("<style> body { text-align: center; } </style>");
            out.println("</head>");
            out.println("<body>");
            out.println("do Post <br>");
            if(gender.equals("male")) {
                out.println("Hello Mr. " + name);
            } else if(gender.equals("female")) {
                out.println("Hello Mrs." + name);
            } else {
                out.println("Hello " + name);
            }
            out.println("! <br>We have receive your information. Please check. <br>");
            out.println("your name is " + name + "<br>");
            out.println("your id is " + id + "<br>");
            out.println("your gender is " + gender + "<br>");
            out.println("your phone is " + phone + "<br>");
            out.println("your mail is " + mail + "<br>");
            out.println("your address is " + address + "<br>");
            out.println("your food is " + Arrays.toString(food) + "<br>");
            out.println("</body>");
            out.println("</html>");
            
            Connection con = DBConnect.connect();
            String foods = "";
            for(int i=0; i<food.length; i++) {
                if(i != 0) {
                    foods += ","+food[i];
                } else {
                    foods += food[i];
                }
            }
            DBConnect.insert(con, name, id, gender, phone, mail, address, foods);
            
            
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
