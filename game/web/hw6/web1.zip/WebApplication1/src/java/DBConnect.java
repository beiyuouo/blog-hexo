/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HNDX
 */
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBConnect {
    public static Connection connect() {
        String username = "root";
        String passwd = "1234";
        String url = "jdbc:mysql://localhost:3306/user";
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url, username, passwd);
            if(con != null) {
                System.out.println("connect success!");
            } else {
                System.out.println("connect failed!");
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DBConnect.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(DBConnect.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            return con;
        }
    }
    public static void insert(Connection con, String name, String id, String gender, String phone, String mail, String address, String food) {
        try {
            String sql = "insert into user values(?,?,?,?,?,?,?);";
            PreparedStatement stm = con.prepareStatement(sql);
            stm.setString(1, name);
            stm.setString(2, id);
            stm.setString(3, gender);
            stm.setString(4, phone);
            stm.setString(5, mail);
            stm.setString(6, address);
            stm.setString(7, food);
            stm.executeUpdate();
            System.out.println("insert success!");
        } catch (SQLException ex) {
            Logger.getLogger(DBConnect.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
